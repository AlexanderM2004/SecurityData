/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdf;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import control.Conexion;
import control.Ussername;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import pdf.uss_Pdf;

public class PlantillaPDF_permisos {

    public void crearPlantilla(Document doc, JTable table, String name) throws DocumentException, IOException {
        try {

            // Configuración de fuentes
            Font fontTitle = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
            Font fontfirmas = new Font(Font.FontFamily.HELVETICA, 8, Font.BOLD);
            Font fontfecha = new Font(Font.FontFamily.HELVETICA, 8, Font.BOLD);
            Font fonttabla = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
            // Título

            Paragraph title = new Paragraph();
            title.setAlignment(Element.ALIGN_CENTER);
            title.setFont(fontTitle);
            title.add("UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE SEDE SANTONOMIGO\n");
            title.add("\nSEGURITY DATA\n");
            title.add("\nREPORTE DE BITÁCORA\n");
            title.add("\nREGISTRO DE PERMISOS PERSONAL MILITAR Y ADMINISTRATIVO\n");
            doc.add(title);
            doc.add(Chunk.NEWLINE);

            // Para colocar imagen de la espe en la esquina superior izquierda
            Image imagenIzquierda = Image.getInstance("src\\pdf\\LOGO ESPE1.png");
            imagenIzquierda.scaleAbsolute(50, 50); // Cambiar tamaño de la imagen si es necesario
            imagenIzquierda.setAbsolutePosition(36, 530); // Posición en coordenadas absolutas
            doc.add(imagenIzquierda);

            // Para colocar imagen de la empresa en la esquina superior derecha
            Image imagenDerecha = Image.getInstance("src\\pdf\\logoprincipal.png");
            imagenDerecha.scaleAbsolute(100, 100); // Cambiar tamaño de la imagen si es necesario
            imagenDerecha.setAbsolutePosition(PageSize.A4.getWidth() - -235 - imagenDerecha.getScaledWidth(), 495); // Posición en coordenadas absolutas
            doc.add(imagenDerecha);
            // Pies de firma
            doc.add(Chunk.NEWLINE);

            DefaultTableModel modelo = (DefaultTableModel) table.getModel();
            PdfPTable tabla = new PdfPTable(modelo.getColumnCount());
            tabla.setWidthPercentage(100);
            String[] titulos = {"Usuario", "Fecha", "Hora Salida", "Hora Ingreso", "Nombre", "Permiso"," Autoriza"};

// Agregar los títulos de las columnas
            for (String titulo : titulos) {
                PdfPCell celdaTitulo = new PdfPCell(new Phrase(titulo)); // Crear una celda con el título
                // Establecer el formato de la celda de título según sea necesario
                // Por ejemplo, establecer el color de fondo o la alineación del texto
                celdaTitulo.setBackgroundColor(BaseColor.LIGHT_GRAY); // Color de fondo
                celdaTitulo.setHorizontalAlignment(Element.ALIGN_CENTER); // Alineación del texto
                // Añadir la celda de título a la tabla PDF
                tabla.addCell(celdaTitulo);
            }
// Copiar datos de la tabla Swing a la tabla PDF
            for (int fila = 0; fila < modelo.getRowCount(); fila++) {
                for (int columna = 0; columna < modelo.getColumnCount(); columna++) {
                    Object valorCelda = modelo.getValueAt(fila, columna);
                    tabla.addCell(valorCelda.toString());
                }
            }
            doc.add(tabla);

            doc.add(Chunk.NEWLINE);
            doc.add(Chunk.NEWLINE);

            PdfPTable tablaFirmas = new PdfPTable(3);
            tablaFirmas.setWidthPercentage(100);

// Primer pie de firma - izquierda
            PdfPCell celdaIzquierda = new PdfPCell(new Phrase(name));
            celdaIzquierda.setBorder(Rectangle.NO_BORDER);
            celdaIzquierda.setHorizontalAlignment(Element.ALIGN_LEFT);
            tablaFirmas.addCell(celdaIzquierda);

// Segundo pie de firma - centro
            PdfPCell celdaCentro = new PdfPCell(new Phrase("CAPT BUSTAMANTE ISRAEL"));
            celdaCentro.setBorder(Rectangle.NO_BORDER);
            celdaCentro.setHorizontalAlignment(Element.ALIGN_CENTER);
            tablaFirmas.addCell(celdaCentro);

// Tercer pie de firma - derecha
            PdfPCell celdaDerecha = new PdfPCell(new Phrase("CRNL NILO MAZA"));
            celdaDerecha.setBorder(Rectangle.NO_BORDER);
            celdaDerecha.setHorizontalAlignment(Element.ALIGN_RIGHT);
            tablaFirmas.addCell(celdaDerecha);

// Añade la tabla de firmas al documento
            doc.add(tablaFirmas);

// Segunda fila de firmas
            PdfPTable tablaFirmas2 = new PdfPTable(3);
            tablaFirmas2.setWidthPercentage(100);

// Primer pie de firma - izquierda
            PdfPCell celdaIzquierda2 = new PdfPCell(new Phrase("USUARIO"));
            celdaIzquierda2.setBorder(Rectangle.NO_BORDER);
            celdaIzquierda2.setHorizontalAlignment(Element.ALIGN_LEFT);
            tablaFirmas2.addCell(celdaIzquierda2);

// Segundo pie de firma - centro
            PdfPCell celdaCentro2 = new PdfPCell(new Phrase("JEFE ADMINISTRATIVO"));
            celdaCentro2.setBorder(Rectangle.NO_BORDER);
            celdaCentro2.setHorizontalAlignment(Element.ALIGN_CENTER);
            tablaFirmas2.addCell(celdaCentro2);

// Tercer pie de firma - derecha
            PdfPCell celdaDerecha2 = new PdfPCell(new Phrase("DIRECTOR DE LA ESPE SD"));
            celdaDerecha2.setBorder(Rectangle.NO_BORDER);
            celdaDerecha2.setHorizontalAlignment(Element.ALIGN_RIGHT);
            tablaFirmas2.addCell(celdaDerecha2);

// Añade la segunda tabla de firmas al documento
            doc.add(tablaFirmas2);
            

            // Fecha del reporte
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            String fecha = sdf.format(new Date());
            Paragraph fechaParagraph = new Paragraph();
            fechaParagraph.setAlignment(Element.ALIGN_RIGHT);
            fechaParagraph.setFont(fontfecha);
            fechaParagraph.add("\nFecha de generación del reporte: " + fecha);
            doc.add(fechaParagraph);

            doc.close();
            JOptionPane.showMessageDialog(null, "El archivo PDF se a creado correctamente!");
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (DocumentException e) {
            System.out.println(e.getMessage());
        }
    }
}
