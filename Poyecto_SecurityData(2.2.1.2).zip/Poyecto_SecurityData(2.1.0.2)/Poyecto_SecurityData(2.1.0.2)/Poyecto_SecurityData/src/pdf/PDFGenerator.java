/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import control.Conexion;
import control.Ussername;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.JTable;

public class PDFGenerator {
 
    public void createPdfpermisos(String dest, JTable table, String name) throws IOException, DocumentException {
        Document document = new Document(PageSize.A4.rotate());
        PdfWriter.getInstance(document, new FileOutputStream(dest));
        document.open();

        PlantillaPDF_permisos plantillaPDF = new PlantillaPDF_permisos();
        plantillaPDF.crearPlantilla(document, table, name);

        document.close();
    }
     public void createPdfnovedades(String dest, JTable table, String name) throws IOException, DocumentException {
        Document document = new Document(PageSize.A4.rotate());
        PdfWriter.getInstance(document, new FileOutputStream(dest));
        document.open();

        PlantillaPDF_novedades plantillaPDF = new PlantillaPDF_novedades();
        plantillaPDF.crearPlantilla(document, table, name);

        document.close();
    }
      public void createPdfvehiculos(String dest, JTable table, String name) throws IOException, DocumentException {
        Document document = new Document(PageSize.A4.rotate());
        PdfWriter.getInstance(document, new FileOutputStream(dest));
        document.open();

        PlantillaPDF_vehiculos plantillaPDF = new PlantillaPDF_vehiculos();
        plantillaPDF.crearPlantilla(document, table, name);

        document.close();
    }
}
