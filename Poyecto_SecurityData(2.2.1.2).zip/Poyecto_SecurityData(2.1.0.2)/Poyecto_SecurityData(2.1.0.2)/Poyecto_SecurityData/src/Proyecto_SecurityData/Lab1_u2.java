package Proyecto_SecurityData;

import com.raven.main.Main;

/**
 *
 * @author Grupo 1
 */
public class Lab1_u2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Main main = new Main();
        main.setVisible(true);

//        HomeAdmin home = new HomeAdmin();
//        home.setVisible(true);

    }
    
}
