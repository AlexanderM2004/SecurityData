package control;

import com.mongodb.MongoClient;
import javax.swing.JOptionPane;
import com.mongodb.client.MongoDatabase;

// Definimos la clase 'Conexion'.
public class Conexion {
    
    public MongoDatabase ConnectDB (){
        MongoDatabase database = null;
        int puerto = 27017; //Puerto del localhost de MongoDB
        String server = "localhost";
        
        try {
            //Conexion a MongoDB
            MongoClient query = new MongoClient(server, puerto);
            database = query.getDatabase("BD_SecurityData");//Nombre de la base de batos
            System.out.println("MONGODB-CONNECT");
            return database;
        } catch (Exception e){
            //Muestra por pantalla un mensaje de error, en caso que la conexion a mongo haya fallado
            JOptionPane.showMessageDialog(null, "Hubo un error al conectar.");
        }
        return database;
    }
   
}
