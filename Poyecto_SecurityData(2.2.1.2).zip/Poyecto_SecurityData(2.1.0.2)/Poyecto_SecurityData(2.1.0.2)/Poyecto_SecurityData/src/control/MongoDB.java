package control;

import com.mongodb.client.*;
import java.awt.HeadlessException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author Grupo 1
 */
public class MongoDB {

    //Conectamos a la base de datos
    public MongoDatabase db = new Conexion().ConnectDB();
    //Se crea una coleccion llamada Novedades para la base de datos
    public MongoCollection<Document> usu = db.getCollection("Usuarios");
    //Se crea una coleccion llamada Novedades para la base de datos
    public MongoCollection<Document> nov = db.getCollection("Novedades");
    //Se crea una coleccion llamada Permisos para la base de datos
    public MongoCollection<Document> per = db.getCollection("Permisos");
    //Se crea una coleccion llamada Vehiculos para la base de datos
    public MongoCollection<Document> vehi = db.getCollection("Vehiculos");

    //Metodo que permite agregar registros a la base de datos
    public void addregister(String ID, String Date, String Hora, String Novedad, String Observacion, DefaultTableModel Model) {
        //Creamos una nota - todavia no se guarda en la base de datos
        Document doc = new Document("Usuario", ID).append("Fecha", Date).append("Hora", Hora).append("Novedad", Novedad).append("Observacion", Observacion);
        try {
            //Insertamos la nota en la coleccion Novedades de la base de datos
            nov.insertOne(doc);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Hubo un error al realizar el registro");
        }
        Model.setRowCount(0);
    }

    //Permite ver los registros ingresados a la base de datos
    public void viewRegister(DefaultTableModel Model) {
        try {
            // Realizar una operación de lectura (por ejemplo, encontrar todos los documentos)
            FindIterable<Document> documents = nov.find();

            // Iterar sobre los documentos e imprimirlos
            for (Document document : documents) {
                // Ajusta los nombres de los campos según tus datos
                Object[] fila = {
                    document.getString("Usuario"),
                    document.getString("Fecha"),
                    document.getString("Hora"),
                    document.getString("Novedad"),
                    document.getString("Observacion"),};
                Model.addRow(fila);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    //Metodo que permite eliminar los registros de la base de datos
    public void deletedRegister(String ID, String Date, String Hora, String Novedad, String Observacion, DefaultTableModel Model, int fila) {
        //Creamos una nota - todavia no se guarda en la base de datos
        Document doc = new Document("Usuario", ID).append("Fecha", Date).append("Hora", Hora).append("Novedad", Novedad).append("Observacion", Observacion);
        // Eliminar el documento en MongoDB
        try {
            nov.deleteOne(doc);
            // Eliminar la fila del modelo de la tabla
            Model.removeRow(fila);
            JOptionPane.showMessageDialog(null, "Fila eliminada con éxito");
        } catch (HeadlessException ex) {
            JOptionPane.showMessageDialog(null, "Error al eliminar la fila", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //Metodo para editar los registros de la base de datos
    public void editRegister(String ID, String Date, String Hora, String Novedad, String Observacion, DefaultTableModel Model, int fila) {

        // Permitir al usuario editar los datos
        String nid = ID;
        String ndate = JOptionPane.showInputDialog(null, "Fecha:", Date);
        String nhora = JOptionPane.showInputDialog(null, "Hora:", Hora);
        String nnoved = JOptionPane.showInputDialog(null, "Tipo de Novedad:", Novedad);
        String nobser = JOptionPane.showInputDialog(null, "Observación:", Observacion);

        Model.setValueAt(nid, fila, 0);
        Model.setValueAt(ndate, fila, 1);
        Model.setValueAt(nhora, fila, 2);
        Model.setValueAt(nnoved, fila, 3);
        Model.setValueAt(nobser, fila, 4);

        // Actualizar los datos en MongoDB
        try {

            // Construir el filtro para identificar el documento a actualizar
            Document filtro = new Document("Usuario", ID).append("Fecha", Date).append("Hora", Hora).append("Novedad", Novedad).append("Observacion", Observacion);
            // Agrega más campos según tus necesidades

            // Construir el documento con los nuevos valores
            Document newValues = new Document("Usuario", nid).append("Fecha", ndate).append("Hora", nhora).append("Novedad", nnoved).append("Observacion", nobser);
            // Agrega más campos según tus necesidades

            // Realizar la actualización en MongoDB
            nov.updateOne(filtro, new Document("$set", newValues));
            JOptionPane.showMessageDialog(null, "Fila editada con éxito");
        } catch (HeadlessException ex) {
            JOptionPane.showMessageDialog(null, "Error al editar la fila", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //Metodo que permite agregar permisos a la base de datos
    public void addpermits(String ID, String Date, String Horaout, String Horain, String Nombre, String Permiso, String Autoriza, DefaultTableModel Model) {
        //Creamos una nota - todavia no se guarda en la base de datos
        Document doc = new Document("Usuario", ID).append("Fecha", Date).append("HoraOut", Horaout).append("HoraIn", Horain).append("Nombre", Nombre).append("Permiso", Permiso).append("Autoriza", Autoriza);
        try {
            //Insertamos la nota en la coleccion Novedades de la base de datos
            per.insertOne(doc);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Hubo un error al realizar el registro");
        }
        Model.setRowCount(0);
    }

    //Permite ver los permisos ingresados a la base de datos
    public void viewpermits(DefaultTableModel Model) {
        try {
            // Realizar una operación de lectura (por ejemplo, encontrar todos los documentos)
            FindIterable<Document> documents = per.find();

            // Iterar sobre los documentos e imprimirlos
            for (Document document : documents) {
                // Ajusta los nombres de los campos según tus datos
                Object[] fila = {
                    document.getString("Usuario"),
                    document.getString("Fecha"),
                    document.getString("HoraOut"),
                    document.getString("HoraIn"),
                    document.getString("Nombre"),
                    document.getString("Permiso"),
                    document.getString("Autoriza"),};
                Model.addRow(fila);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    

    //Metodo que permite eliminar los permisos de la base de datos
    public void deletePermits(String ID, String Date, String Horaout, String Horain, String Nombre, String Permiso, String Autoriza, DefaultTableModel Model, int fila) {
        //Creamos una nota - todavia no se guarda en la base de datos
        Document doc = new Document("Usuario", ID).append("Fecha", Date).append("HoraOut", Horaout).append("HoraIn", Horain).append("Nombre", Nombre).append("Permiso", Permiso).append("Autoriza", Autoriza);
        // Eliminar el documento en MongoDB
        try {
            per.deleteOne(doc);
            // Eliminar la fila del modelo de la tabla
            Model.removeRow(fila);
            JOptionPane.showMessageDialog(null, "Fila eliminada con éxito");
        } catch (HeadlessException ex) {
            JOptionPane.showMessageDialog(null, "Error al eliminar la fila", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void editPermits(String ID, String Date, String Horaout, String Horain, String Nombre, String Permiso, String Autoriza, DefaultTableModel Model, int fila) {
        // Permitir al usuario editar los datos
        String nid = ID;
        String ndate = JOptionPane.showInputDialog(null, "Fecha:", Date);
        String nhoraout = JOptionPane.showInputDialog(null, "Hora de Salida:", Horaout);
        String nhorain = JOptionPane.showInputDialog(null, "Hora de Entrada:", Horain);
        String nnombre = JOptionPane.showInputDialog(null, "Nombre:", Nombre);
        String npermiso = JOptionPane.showInputDialog(null, "Tipo de Permiso:", Permiso);
        String nautoriza = JOptionPane.showInputDialog(null, "Autoriza: ", Autoriza);

        Model.setValueAt(nid, fila, 0);
        Model.setValueAt(ndate, fila, 1);
        Model.setValueAt(nhoraout, fila, 2);
        Model.setValueAt(nhorain, fila, 3);
        Model.setValueAt(nnombre, fila, 4);
        Model.setValueAt(npermiso, fila, 5);
        Model.setValueAt(nautoriza, fila, 6);

        // Actualizar los datos en MongoDB
        try {
            // Construir el filtro para identificar el documento a actualizar
            Document filtro = new Document("Usuario", ID).append("Fecha", Date).append("HoraOut", Horaout).append("HoraIn", Horain).append("Nombre", Nombre).append("Permiso", Permiso).append("Autoriza", Autoriza);
            // Agrega más campos según tus necesidades

            // Construir el documento con los nuevos valores
            Document newValues = new Document("Usuario", nid).append("Fecha", ndate).append("HoraOut", nhoraout).append("HoraIn", nhorain).append("Nombre", nnombre).append("Permiso", npermiso).append("Autoriza", nautoriza);
            // Agrega más campos según tus necesidades

            // Realizar la actualización en MongoDB
            per.updateOne(filtro, new Document("$set", newValues));
            JOptionPane.showMessageDialog(null, "Fila editada con éxito");
        } catch (HeadlessException ex) {
            JOptionPane.showMessageDialog(null, "Error al editar la fila", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //Metodo que permite agregar permisos a la base de datos
    public void addvehicle(String ID, String Date, String Hora, String Placa, String Nombre, String Observacion, DefaultTableModel Model) {
        //Creamos una nota - todavia no se guarda en la base de datos
        Document doc = new Document("Usuario", ID).append("Fecha", Date).append("Hora", Hora).append("Placa", Placa).append("Nombre", Nombre).append("Observacion", Observacion);
        try {
            //Insertamos la nota en la coleccion Novedades de la base de datos
            vehi.insertOne(doc);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Hubo un error al realizar el registro");
        }
        Model.setRowCount(0);
    }

    //Permite ver los permisos ingresados a la base de datos
    public void viewvehicle(DefaultTableModel Model) {
        try {
            // Realizar una operación de lectura (por ejemplo, encontrar todos los documentos)
            FindIterable<Document> documents = vehi.find();

            // Iterar sobre los documentos e imprimirlos
            for (Document document : documents) {
                // Ajusta los nombres de los campos según tus datos
                Object[] fila = {
                    document.getString("Usuario"),
                    document.getString("Fecha"),
                    document.getString("Hora"),
                    document.getString("Placa"),
                    document.getString("Nombre"),
                    document.getString("Observacion"),};
                Model.addRow(fila);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    //Metodo que permite eliminar los permisos de la base de datos
    public void deleteVehicle(String ID, String Date, String Hora, String Placa, String Nombre, String Observacion, DefaultTableModel Model, int fila) {
        //Creamos una nota - todavia no se guarda en la base de datos
        Document doc = new Document("Usuario", ID).append("Fecha", Date).append("Hora", Hora).append("Placa", Placa).append("Nombre", Nombre).append("Observacion", Observacion);
        // Eliminar el documento en MongoDB
        try {
            vehi.deleteOne(doc);
            // Eliminar la fila del modelo de la tabla
            Model.removeRow(fila);
            JOptionPane.showMessageDialog(null, "Fila eliminada con éxito");
        } catch (HeadlessException ex) {
            JOptionPane.showMessageDialog(null, "Error al eliminar la fila", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void editVehicle(String ID, String Date, String Hora, String Placa, String Nombre, String Observacion, DefaultTableModel Model, int fila) {
        String nid = ID;
        String ndate = JOptionPane.showInputDialog(null, "Fecha:", Date);
        String nhora = JOptionPane.showInputDialog(null, "Hora", Hora);
        String nplaca = JOptionPane.showInputDialog(null, "Placa del Vehiculo", Placa);
        String nnombre = JOptionPane.showInputDialog(null, "Nombre:", Nombre);
        String nobser = JOptionPane.showInputDialog(null, "Observacion:", Observacion);

        Model.setValueAt(nid, fila, 0);
        Model.setValueAt(ndate, fila, 1);
        Model.setValueAt(nhora, fila, 2);
        Model.setValueAt(nplaca, fila, 3);
        Model.setValueAt(nnombre, fila, 4);
        Model.setValueAt(nobser, fila, 5);

        // Actualizar los datos en MongoDB
        try {
            // Construir el filtro para identificar el documento a actualizar
            Document filtro = new Document("Usuario", ID).append("Fecha", Date).append("Hora", Hora).append("Placa", Placa).append("Nombre", Nombre).append("Observacion", Observacion);
            // Agrega más campos según tus necesidades

            // Construir el documento con los nuevos valores
            Document newValues = new Document("Usuario", nid).append("Fecha", ndate).append("Hora", nhora).append("Placa", nplaca).append("Nombre", nnombre).append("Observacion", nobser);
            // Agrega más campos según tus necesidades

            // Realizar la actualización en MongoDB
            vehi.updateOne(filtro, new Document("$set", newValues));
            JOptionPane.showMessageDialog(null, "Fila editada con éxito");
        } catch (HeadlessException ex) {
            JOptionPane.showMessageDialog(null, "Error al editar la fila", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //Permite mantener persistencia de datos al iniciar sesion y en el uso del todo el programa
    public String viewUser(String ID) {
        // Realizar la consulta para la autenticación
        // Crear un documento con los datos de inicio de sesión
        Document loginAdmind = new Document("id", ID);
        Document user = usu.find(loginAdmind).first();
        String nombre = user.getString("name"); //Se recupera de la base datos el nombre del Usuario
        String apellido = user.getString("lastname");//Se recupera de la base de datos el apellido del Usuario
        //Retora los nombre del usuario
        return nombre + " " + apellido;
    }

}
