package control;

/**
 *
 * @author Grupo 1
 */
public class Ussername {
    //VAriable que va a usarse para la persistencia de datos al momento de iniciar sesion
    protected String usernam;

    //Metodo get,que devuelve el valor alamecenado en esa variable 
    public String getUsernam() {
        return usernam;
    }

    //Metodo set, que permite ingresar valores a la variable designada
    public void setUsernam(String usernam) {
        this.usernam = usernam;
    }
}
