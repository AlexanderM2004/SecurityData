package com.raven.component;

import Admind.HomeAdmin;
import Usser.Home;
import com.mongodb.client.*;
import com.raven.swing.Button;
import com.raven.swing.*;
import control.Conexion;
import control.Ussername;
import java.awt.*;
import javax.swing.*;
import net.miginfocom.swing.MigLayout;
import org.bson.Document;

public class PanelLoginAndRegister extends javax.swing.JLayeredPane {

    Ussername name = new Ussername();
    //Conectamos a la base de datos
    public MongoDatabase db = new Conexion().ConnectDB(); 
    //Coleccion de Usuarios
    public MongoCollection<Document> docen = db.getCollection("Usuarios");
    //Coleccion de Administrador
    public MongoCollection<Document> admin = db.getCollection("Administrador");
    
    Button cmd = new Button();
    Button cmd2 = new Button();
    MyPasswordField txtPass = new MyPasswordField();
    MyTextField txtClient = new MyTextField();
    MyPasswordField txtPass1 = new MyPasswordField();
    MyTextField txtAdmin = new MyTextField();
    public PanelLoginAndRegister() {
        initComponents();
        initRegister();
        initLogin();
        login.setVisible(false);
        register.setVisible(true);
        //Boton de accion de inicio de sesion para el administrador
        cmd.addActionListener((java.awt.event.ActionEvent evt) -> {
            LoginAdmin();
        });
        //Boton de accion de inicio de sesion para el Usuario
        cmd2.addActionListener((java.awt.event.ActionEvent evt) -> {
            LoginUsser();
        });
        
    }

    private void initRegister() {
        register.setLayout(new MigLayout("wrap", "push[center]push", "push[]25[]10[]10[]25[]push"));
        JLabel label = new JLabel("SegurityData - Administrador");
        label.setFont(new Font("sansserif", 1, 30));
        label.setForeground(new Color(52, 45, 153));
        register.add(label);
        
        txtAdmin.setPrefixIcon(new ImageIcon(getClass().getResource("/com/raven/icon/user.png")));
        txtAdmin.setHint("Ussername");
        register.add(txtAdmin, "w 60%");
        
        txtPass1.setPrefixIcon(new ImageIcon(getClass().getResource("/com/raven/icon/pass.png")));
        txtPass1.setHint("Password");
        register.add(txtPass1, "w 60%");
        
        cmd.setBackground(new Color(52, 45, 153));
        cmd.setForeground(new Color(250, 250, 250));
        cmd.setText("INICIAR SESIÓN");
        register.add(cmd, "w 40%, h 40");
    }

    private void initLogin() {
        login.setLayout(new MigLayout("wrap", "push[center]push", "push[]25[]10[]10[]25[]push"));
        JLabel label = new JLabel("SegurityData");
        label.setFont(new Font("sansserif", 1, 30));
        label.setForeground(new Color(52, 45, 153));
        login.add(label);
        
        txtClient.setPrefixIcon(new ImageIcon(getClass().getResource("/com/raven/icon/user.png")));
        txtClient.setHint("Usser ID");
        login.add(txtClient, "w 60%");
        
        txtPass.setPrefixIcon(new ImageIcon(getClass().getResource("/com/raven/icon/pass.png")));
        txtPass.setHint("Password");
        login.add(txtPass, "w 60%");
        
        cmd2.setBackground(new Color(52, 45, 153));
        cmd2.setForeground(new Color(250, 250, 250));
        cmd2.setText("INICIAR SESIÓN");
        login.add(cmd2, "w 40%, h 40");
    }

    public void showRegister(boolean show) {
        if (show) {
            register.setVisible(true);
            login.setVisible(false);
        } else {
            register.setVisible(false);
            login.setVisible(true);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        login = new javax.swing.JPanel();
        register = new javax.swing.JPanel();

        setLayout(new java.awt.CardLayout());

        login.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout loginLayout = new javax.swing.GroupLayout(login);
        login.setLayout(loginLayout);
        loginLayout.setHorizontalGroup(
            loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 327, Short.MAX_VALUE)
        );
        loginLayout.setVerticalGroup(
            loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        add(login, "card3");

        register.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout registerLayout = new javax.swing.GroupLayout(register);
        register.setLayout(registerLayout);
        registerLayout.setHorizontalGroup(
            registerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 327, Short.MAX_VALUE)
        );
        registerLayout.setVerticalGroup(
            registerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        add(register, "card2");
    }// </editor-fold>//GEN-END:initComponents

    //private void IniciarActionPerformed(ActionEvent evt) {
        //Login();
        
    //}
    
    public void LoginAdmin(){
        try {
            // Datos de inicio de sesión
            String usser = txtAdmin.getText();
            String pass = txtPass1.getText();

            if(usser.isEmpty() || pass.isEmpty()) {
                // Manejar el caso en el que los campos estén vacíos
                JOptionPane.showMessageDialog(this, "Hay campos sin llenar, por favor llene todos los campos", "Error al iniciar sesion", JOptionPane.ERROR_MESSAGE);
            }else{
                // Crear un documento con los datos de inicio de sesión
                Document loginAdmind = new Document("username", usser).append("password", pass);

                // Realizar la consulta para la autenticación
                Document user = admin.find(loginAdmind).first();
                //Si la validacion es un exito se puede acceder al sistema.
                if (user != null) {
                    this.setVisible(false); //Se cierra la venta actual 
                    HomeAdmin homead = new HomeAdmin();
                    homead.setVisible(true);//Se abre la ventana principal del administrador
                    JOptionPane.showMessageDialog(null, "Inicio de sesión exitoso");
                } else {
                    //Muestra por patalla un mesaje de error en caso de que los datos ingresados no existan en el sistema.
                    JOptionPane.showMessageDialog(this, "Error de inicio de sesión. Verifica las credenciales", "Error al iniciar sesion", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (HeadlessException e) {
            System.out.println(e);
        }
    }
    
    public void LoginUsser(){
        try {
            // Datos de inicio de sesión
            String usse = txtClient.getText();
            String pas = txtPass.getText();
            //Verifica que los campos no esten vacios
            if(usse.isEmpty() || pas.isEmpty()) {
                // Manejar el caso en el que los campos estén vacíos
                JOptionPane.showMessageDialog(this, "Hay campos sin llenar, por favor llene todos los campos", "Error al iniciar sesion", JOptionPane.ERROR_MESSAGE);
            }else{
                // Crear un documento con los datos de inicio de sesión
                Document loginAdmind = new Document("id", usse).append("pass", pas);

                // Realizar la consulta para la autenticación
                Document user = docen.find(loginAdmind).first();
                //Si la validacion es un exito se puede acceder al sistema.
                if (user != null) {
                    this.setVisible(false);//Se cierra la ventana actual
                    Home home = new Home(name);
                    home.setVisible(true);//Se abre la ventana principal del usuario
                    String nombre = user.getString("name"); //Se recupera de la base datos el nombre del Usuario
                    String apellido = user.getString("lastname");//Se recupera de la base de datos el apellido del Usuario
                    //Se guardan los datos de registro del usuario para la persistencia de los mismos
                    name.setUsernam(usse);
                    System.out.println(name.getUsernam());
                    //Muestra por pantalla un mensaje de bienvenida
                    JOptionPane.showMessageDialog(null, "Bienvenido "+nombre+" "+apellido);
                } else {
                    //Muestra por patalla un mesaje de error en caso de que los datos ingresados no existan en el sistema.
                    JOptionPane.showMessageDialog(this, "Error de inicio de sesión. Verifica las credenciales", "Error al iniciar sesion", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (HeadlessException e) {
            System.out.println(e);
        }
    }
       
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel login;
    private javax.swing.JPanel register;
    // End of variables declaration//GEN-END:variables
}
